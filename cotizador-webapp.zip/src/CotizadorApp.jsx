
import React, { useState } from 'react';
import jsPDF from 'jspdf';
import 'jspdf-autotable';

const productos = [
  {
    codigo: 'AMBACC001',
    descripcion: 'CARGADOR AMBU ASCOPE 3',
    precio: 60000,
  },
  {
    codigo: 'AMBAUG001',
    descripcion: 'MASC.LARINGEA A-GAIN #3',
    precio: 18800,
  },
  {
    codigo: 'AMBAUG002',
    descripcion: 'MASC.LARINGEA A-GAIN #4',
    precio: 18800,
  },
];

export default function CotizadorApp() {
  const [cliente, setCliente] = useState('');
  const [seleccionados, setSeleccionados] = useState([]);

  const agregarProducto = (producto) => {
    setSeleccionados((prev) => {
      const existe = prev.find((p) => p.codigo === producto.codigo);
      if (existe) {
        return prev.map((p) =>
          p.codigo === producto.codigo ? { ...p, cantidad: p.cantidad + 1 } : p
        );
      }
      return [...prev, { ...producto, cantidad: 1 }];
    });
  };

  const generarPDF = () => {
    const doc = new jsPDF();
    doc.text(`Cotización para: ${cliente}`, 10, 10);

    const rows = seleccionados.map((p) => [
      p.codigo,
      p.descripcion,
      p.cantidad,
      `$${p.precio.toLocaleString()}`,
      `$${(p.precio * p.cantidad).toLocaleString()}`,
    ]);

    doc.autoTable({
      head: [['Código', 'Descripción', 'Cantidad', 'Precio Unitario', 'Total']],
      body: rows,
    });

    const total = seleccionados.reduce(
      (sum, p) => sum + p.precio * p.cantidad,
      0
    );
    doc.text(`Total: $${total.toLocaleString()}`, 10, doc.autoTable.previous.finalY + 10);

    doc.save('cotizacion.pdf');
  };

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Cotizador de Productos</h1>

      <input
        type="text"
        placeholder="Nombre del Cliente"
        className="border rounded px-3 py-2 mb-4 w-full"
        value={cliente}
        onChange={(e) => setCliente(e.target.value)}
      />

      <h2 className="text-xl font-semibold mb-2">Productos Disponibles</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        {productos.map((p) => (
          <div
            key={p.codigo}
            className="border p-3 rounded shadow flex justify-between items-center"
          >
            <div>
              <p className="font-medium">{p.descripcion}</p>
              <p className="text-sm text-gray-600">${p.precio.toLocaleString()}</p>
            </div>
            <button onClick={() => agregarProducto(p)}>Agregar</button>
          </div>
        ))}
      </div>

      <h2 className="text-xl font-semibold mb-2">Resumen</h2>
      <ul className="mb-4">
        {seleccionados.map((p) => (
          <li key={p.codigo}>
            {p.descripcion} - Cant: {p.cantidad} - Total: ${p.precio * p.cantidad}
          </li>
        ))}
      </ul>

      <button onClick={generarPDF} className="mt-4">Generar PDF</button>
    </div>
  );
}
